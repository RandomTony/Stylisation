#define LIME_API_EXPORT
#include "misc.hpp"
