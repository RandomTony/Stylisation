#define LIME_API_EXPORT
#include "npr.hpp"
