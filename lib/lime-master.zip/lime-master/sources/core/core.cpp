#define LIME_API_EXPORT
#include "core.hpp"
