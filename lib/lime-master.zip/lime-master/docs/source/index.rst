.. Lime documentation master file, created by
   sphinx-quickstart on Sun Nov 20 13:13:51 2016.

Welcome to Lime's documentation!
================================

Lime (Library for IMage Editing) is an image editing library extending OpenCV 3.x
which is developed for C/C++ and Python.

.. toctree::
   :maxdepth: 1

   install
   reference/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
