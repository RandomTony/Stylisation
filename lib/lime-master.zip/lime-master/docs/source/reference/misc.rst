Misc module
============

----------------
Color constancy
----------------

.. doxygenfunction:: lime::colorConstancy

.. doxygenenum:: lime::ConstancyType
